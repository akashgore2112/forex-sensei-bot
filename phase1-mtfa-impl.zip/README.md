
# Phase 1 – MTFA (Daily/Weekly/Monthly EMA Bias)

**What this does**
- Fetches FX OHLC data from Alpha Vantage for Daily/Weekly/Monthly
- Computes EMA20/EMA50 on each timeframe
- Produces a bias per TF and an overall bias + confidence
- Works for multiple pairs: set env `PAIRS="EUR/USD,GBP/USD"`

**Setup**
1. `npm install axios dotenv`
2. Export your Alpha Vantage key:
   - mac/linux: `export ALPHAVANTAGE_API_KEY=YOUR_KEY`
   - windows (powershell): `$env:ALPHAVANTAGE_API_KEY="YOUR_KEY"`
3. (Optional) set pairs: `export PAIRS="EUR/USD,USD/JPY"`
4. Run: `node phase1/index.js`

**Files**
- `phase1/config.js` – keys, cache & lookbacks
- `phase1/utils/cache.js` – simple file cache in `/cache`
- `phase1/utils/rate-limiter.js` – respects API free limits
- `phase1/data/alpha-vantage.js` – API wrapper
- `phase1/data/data-fetcher.js` – cached fetchers for TFs
- `phase1/indicators/*` – EMA and indicator hub
- `phase1/mtfa/mtfa.js` – main orchestration (`analyzePair`, `analyzeMulti`)
- `phase1/index.js` – runnable example

**Output sample**
```json
[
  {
    "pair": "EUR/USD",
    "time": "2025-10-06T12:00:00.000Z",
    "indicators": {
      "daily": {"ema20": 1.0812, "ema50": 1.0791},
      "weekly":{"ema20": 1.0845, "ema50": 1.0889},
      "monthly":{"ema20": 1.0950, "ema50": 1.1020}
    },
    "biases": { "daily":"BULLISH","weekly":"BEARISH","monthly":"BEARISH" },
    "overallBias": "BEARISH",
    "confidence": 75
  }
]
```

> Phase 1 is **data + bias only**. No signals fired here. Its output feeds later phases.
