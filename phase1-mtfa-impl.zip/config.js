// phase1/config.js
module.exports = {
  ALPHAVANTAGE_API_KEY: process.env.ALPHAVANTAGE_API_KEY || "",
  CACHE_DIR: process.env.CACHE_DIR || "cache",
  // Alpha Vantage free plan: 5 req/min (use 12s gap)
  RATE_LIMIT: { maxPerMinute: 5 },
  // How many candles to request/use per TF
  LOOKBACK: {
    DAILY: 400,
    WEEKLY: 400,
    MONTHLY: 240
  }
};