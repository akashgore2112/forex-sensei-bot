// phase1/data/alpha-vantage.js
const axios = require("axios");
const { ALPHAVANTAGE_API_KEY } = require("../config");

const BASE_URL = "https://www.alphavantage.co/query";

async function call(params) {
  if (!ALPHAVANTAGE_API_KEY) {
    throw new Error("Missing ALPHAVANTAGE_API_KEY env var for Phase1.");
  }
  const { data } = await axios.get(BASE_URL, { params: { ...params, apikey: ALPHAVANTAGE_API_KEY } });
  if (data && data["Error Message"]) throw new Error(data["Error Message"]);
  return data;
}

function parseFXSeries(obj, key) {
  const series = obj[key];
  if (!series) return [];
  // Convert to sorted [{time, open, high, low, close}]
  const rows = Object.entries(series).map(([ts, ohlc]) => ({
    time: ts,
    open: +ohlc["1. open"],
    high: +ohlc["2. high"],
    low: +ohlc["3. low"],
    close: +ohlc["4. close"],
  }));
  // Sort ascending
  rows.sort((a,b) => new Date(a.time) - new Date(b.time));
  return rows;
}

module.exports = {
  async fxDaily(from, to, outputsize="full") {
    const data = await call({ function: "FX_DAILY", from_symbol: from, to_symbol: to, outputsize });
    return parseFXSeries(data, "Time Series FX (Daily)");
  },
  async fxWeekly(from, to) {
    const data = await call({ function: "FX_WEEKLY", from_symbol: from, to_symbol: to });
    return parseFXSeries(data, "Time Series FX (Weekly)");
  },
  async fxMonthly(from, to) {
    const data = await call({ function: "FX_MONTHLY", from_symbol: from, to_symbol: to });
    return parseFXSeries(data, "Time Series FX (Monthly)");
  }
};