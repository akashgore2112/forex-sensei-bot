// phase1/data/data-fetcher.js
const Cache = require("../utils/cache");
const RateLimiter = require("../utils/rate-limiter");
const AV = require("./alpha-vantage");
const { LOOKBACK, CACHE_DIR, RATE_LIMIT } = require("../config");

const cache = new Cache(CACHE_DIR);
const limiter = new RateLimiter(RATE_LIMIT.maxPerMinute);

function splitPair(pair) {
  const [base, quote] = pair.replace("_","/").split("/");
  return [base, quote];
}

async function cachedFetch(key, maxAgeMin, fetcher) {
  const cached = cache.get(key, maxAgeMin);
  if (cached) return cached;
  await limiter.wait();
  const data = await fetcher();
  cache.set(key, data);
  return data;
}

module.exports = {
  async getDaily(pair) {
    const [base, quote] = splitPair(pair);
    const key = `${base}_${quote}_DAILY`;
    const data = await cachedFetch(key, 60, () => AV.fxDaily(base, quote, "full"));
    return data.slice(-LOOKBACK.DAILY);
  },
  async getWeekly(pair) {
    const [base, quote] = splitPair(pair);
    const key = `${base}_${quote}_WEEKLY`;
    const data = await cachedFetch(key, 60*24*3, () => AV.fxWeekly(base, quote)); // 3 days cache
    return data.slice(-LOOKBACK.WEEKLY);
  },
  async getMonthly(pair) {
    const [base, quote] = splitPair(pair);
    const key = `${base}_${quote}_MONTHLY`;
    const data = await cachedFetch(key, 60*24*7, () => AV.fxMonthly(base, quote)); // 7 days cache
    return data.slice(-LOOKBACK.MONTHLY);
  }
};