// phase1/index.js
// Usage example: MTFA for one or more pairs
require("dotenv").config();
const { analyzeMulti } = require("./mtfa/mtfa");

(async ()=>{
  const pairs = (process.env.PAIRS || "EUR/USD").split(",").map(s => s.trim());
  const res = await analyzeMulti(pairs);
  console.log(JSON.stringify(res, null, 2));
})();