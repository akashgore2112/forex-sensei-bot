// phase1/indicators/ema.js
function ema(values, period) {
  if (!values || values.length === 0) return [];
  const k = 2 / (period + 1);
  const out = [];
  let emaPrev = values[0];
  out.push(emaPrev);
  for (let i=1;i<values.length;i++){
    emaPrev = values[i] * k + emaPrev * (1 - k);
    out.push(emaPrev);
  }
  return out;
}
module.exports = { ema };