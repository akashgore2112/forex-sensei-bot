// phase1/indicators/index.js
const { ema } = require("./ema");

async function computeBasic(candles, opts = { ema20: true, ema50: true }) {
  const closes = candles.map(c => c.close);
  const out = {};
  if (opts.ema20) out.ema20 = ema(closes, 20).slice(-1)[0];
  if (opts.ema50) out.ema50 = ema(closes, 50).slice(-1)[0];
  return out;
}

module.exports = { computeBasic };