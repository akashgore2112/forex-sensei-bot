// phase1/mtfa/mtfa.js
// Multi-Timeframe Technical Analysis (Daily/Weekly/Monthly) with EMA bias
const Fetcher = require("../data/data-fetcher");
const Indicators = require("../indicators");

function biasFrom(ind) {
  if (!ind || ind.ema20 == null || ind.ema50 == null) return "NEUTRAL";
  if (ind.ema20 > ind.ema50) return "BULLISH";
  if (ind.ema20 < ind.ema50) return "BEARISH";
  return "NEUTRAL";
}

function combineBias(d, w, m) {
  const biases = [d, w, m];
  const bull = biases.filter(b => b === "BULLISH").length;
  const bear = biases.filter(b => b === "BEARISH").length;
  let overall = "NEUTRAL";
  let confidence = 50;
  if (bull === 3) { overall = "BULLISH"; confidence = 100; }
  else if (bear === 3) { overall = "BEARISH"; confidence = 100; }
  else if (bull === 2 && bear === 0) { overall = "BULLISH"; confidence = 75; }
  else if (bear === 2 && bull === 0) { overall = "BEARISH"; confidence = 75; }
  else if ((bull === 1 && bear === 0) || (bear === 1 && bull === 0)) { overall = biases.find(b=>b!=="NEUTRAL") || "NEUTRAL"; confidence = 60; }
  return { overallBias: overall, confidence, breakdown: { daily: d, weekly: w, monthly: m } };
}

async function analyzePair(pair) {
  // Fetch
  const [daily, weekly, monthly] = await Promise.all([
    Fetcher.getDaily(pair),
    Fetcher.getWeekly(pair),
    Fetcher.getMonthly(pair)
  ]);

  if (!daily.length || !weekly.length || !monthly.length) {
    return { pair, error: "Insufficient data fetched", daily, weekly, monthly };
  }

  // Indicators
  const [dInd, wInd, mInd] = await Promise.all([
    Indicators.computeBasic(daily),
    Indicators.computeBasic(weekly),
    Indicators.computeBasic(monthly)
  ]);

  const dBias = biasFrom(dInd);
  const wBias = biasFrom(wInd);
  const mBias = biasFrom(mInd);
  const combo = combineBias(dBias, wBias, mBias);

  return {
    pair,
    time: new Date().toISOString(),
    indicators: { daily: dInd, weekly: wInd, monthly: mInd },
    biases: { daily: dBias, weekly: wBias, monthly: mBias },
    overallBias: combo.overallBias,
    confidence: combo.confidence
  };
}

async function analyzeMulti(pairs) {
  const results = [];
  for (const p of pairs) {
    try {
      results.push(await analyzePair(p));
    } catch (e) {
      results.push({ pair: p, error: e.message });
    }
  }
  return results;
}

module.exports = { analyzePair, analyzeMulti };