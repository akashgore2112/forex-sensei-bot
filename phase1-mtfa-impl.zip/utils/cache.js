// phase1/utils/cache.js
const fs = require("fs");
const path = require("path");

class Cache {
  constructor(baseDir = "cache") {
    this.baseDir = baseDir;
    if (!fs.existsSync(baseDir)) fs.mkdirSync(baseDir, { recursive: true });
  }
  _keyToPath(key) {
    return path.join(this.baseDir, key.replace(/[^a-zA-Z0-9_\-]/g, "_") + ".json");
  }
  get(key, maxAgeMinutes = null) {
    const p = this._keyToPath(key);
    if (!fs.existsSync(p)) return null;
    const stat = fs.statSync(p);
    if (maxAgeMinutes != null) {
      const ageMin = (Date.now() - stat.mtimeMs) / 60000;
      if (ageMin > maxAgeMinutes) return null;
    }
    try {
      return JSON.parse(fs.readFileSync(p, "utf-8"));
    } catch {
      return null;
    }
  }
  set(key, value) {
    const p = this._keyToPath(key);
    fs.writeFileSync(p, JSON.stringify(value, null, 2));
  }
}
module.exports = Cache;