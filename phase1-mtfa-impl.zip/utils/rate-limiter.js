// phase1/utils/rate-limiter.js
class RateLimiter {
  constructor(maxPerMinute = 5) {
    this.maxPerMinute = maxPerMinute;
    this.calls = [];
  }
  async wait() {
    const now = Date.now();
    // prune
    this.calls = this.calls.filter(t => now - t < 60000);
    if (this.calls.length >= this.maxPerMinute) {
      const waitMs = 60000 - (now - this.calls[0]);
      await new Promise(r => setTimeout(r, waitMs));
      return this.wait(); // after wait, re-check
    }
    this.calls.push(Date.now());
  }
}
module.exports = RateLimiter;